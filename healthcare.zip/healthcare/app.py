from flask import Flask, render_template, url_for, request, session
import sqlite3
import os
import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/Dhome')
def Dhome():
    return render_template('doctorlog.html')

@app.route('/doctorlog', methods=['GET', 'POST'])
def doctorlog():
    if request.method == 'POST':

        name = request.form['name']
        password = request.form['password']
        hospital = request.form['hospital']

        connection = sqlite3.connect(hospital+'.db')
        cursor = connection.cursor()

        query = "SELECT * FROM doctor WHERE name = '"+name+"' AND password= '"+password+"'"
        cursor.execute(query)

        result = cursor.fetchone()

        if result:
            session['hospital'] = hospital
            return render_template('doctorlog.html')
        else:
            return render_template('index.html', msg='Sorry, Incorrect Credentials Provided,  Try Again')

    return render_template('index.html')


@app.route('/doctorreg', methods=['GET', 'POST'])
def doctorreg():
    if request.method == 'POST':

        name = request.form['name']
        password = request.form['password']
        mobile = request.form['phone']
        email = request.form['email']
        hospital = request.form['hospital']
        
        connection = sqlite3.connect(hospital+'.db')
        cursor = connection.cursor()
        session['hospital'] = hospital

        print(name, mobile, email, password, hospital)

        command = "CREATE TABLE IF NOT EXISTS doctor(name TEXT, password TEXT, mobile TEXT, email TEXT, hospital TEXT)"
        cursor.execute(command)

        cursor.execute("INSERT INTO doctor VALUES ('"+name+"', '"+password+"', '"+mobile+"', '"+email+"', '"+hospital+"')")
        connection.commit()

        return render_template('index.html', msg='Successfully Registered')
    
    return render_template('index.html')

@app.route('/Scan', methods=['GET', 'POST'])
def Scan():
    if request.method == 'POST':
        Type = request.form['Type']
        if Type == 'RFID':
            from serial_test import read_data()
            ID = read_data()
        else:
            from reader import getData
            ID = getData()

        connection = sqlite3.connect(session['hospital']+'.db')
        cursor = connection.cursor()
        
        command = "CREATE TABLE IF NOT EXISTS records(ID TEXT, name TEXT, age TEXT, disease TEXT, medicine TEXT, date TEXT, time TEXT)"
        cursor.execute(command)
        
        cursor.execute("select * from records where ID = '"+ID+"'")
        result = cursor.fetchall()
        if result:
            return render_template('doctorlog.html', result=result, ID=ID)
        else:
            return render_template('doctorlog.html', ID=ID)
    return render_template('doctorlog.html')

@app.route('/addrecord', methods=['GET', 'POST'])
def addrecord():
    if request.method == 'POST':
        connection = sqlite3.connect(session['hospital']+'.db')
        cursor = connection.cursor()
        ID = request.form['ID']
        name = request.form['name']
        age = request.form['age']
        disease = request.form['disease']
        medicine = request.form['medicine']

        date = datetime.date.today().strftime('%Y-%m-%d')
        Time = datetime.datetime.now().time().strftime('%H:%M:%S')
        
        cursor.execute("INSERT INTO records VALUES ('"+ID+"', '"+name+"', '"+age+"', '"+disease+"', '"+medicine+"','"+date+"', '"+Time+"')")
        connection.commit()
        return render_template('doctorlog.html')
    return render_template('doctorlog.html')

@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
