import serial
import time

data = serial.Serial(
                  'COM4',
                  baudrate = 9600,
                  parity=serial.PARITY_NONE,
                  stopbits=serial.STOPBITS_ONE,
                  bytesize=serial.EIGHTBITS,                  
                  timeout=1
                  )

def read_data():
    print('reading.....')
    while True:
        d = data.read(12)
        d = d.decode('UTF-8', 'ignore')
        d = d.strip()
        if len(d) == 12:
            print(d)
            break
    return d
