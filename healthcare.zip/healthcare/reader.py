import cv2
from pyzbar.pyzbar import decode

def getData():
	vs = cv2.VideoCapture(0)
	while True:

		ret, img = vs.read()
		detectedBarcodes = decode(img)
		
		d=''
		t=''
		
		for barcode in detectedBarcodes:
			(x, y, w, h) = barcode.rect
			cv2.rectangle(img, (x-10, y-10),
						(x + w+10, y + h+10),
						(255, 0, 0), 2)
			
			d = barcode.data
			t = barcode.type
			
		if d != "":
			break
		cv2.imshow("Image", img)
		if cv2.waitKey(1) & 0xFF == ord('q'):
			break

	vs.release()
	cv2.destroyAllWindows()
	d = d.decode('utf-8', 'ignore')
	print(d)
	return d
